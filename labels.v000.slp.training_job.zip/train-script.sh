#!/bin/bash
sleap-train single_instance.json labels.v000.pkg.slp
