#!/bin/bash
sleap-track C:\Data\Videos\C57hp1.avi --frames 96,33,160,131,106,170,172,141,78,79,145,114,53,157,119,56,183,92,61,62 -m 210423_163714.single_instance -o C57hp1.avi.predictions.slp --verbosity json --no-empty-frames
